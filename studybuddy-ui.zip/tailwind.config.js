/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        muted: "hsl(var(--muted))",
        primary: "hsl(var(--primary))"
      }
    },
  },
  plugins: [],
};
